Kirby's Dream Land (USA, Europe)
-  DX
-  Revisited



Latest:
2021-09-19



______________________________________________________________



black_fade

*  Fixes brief white flicker glitch during dark room transitions




double_speed

*  Fixes music timer during transition
*  Fixes cpu speed after soft reset




fade_palette

*  Fixes palette effects with screen transitions




hud_color

*  Gives HUD color scheme from Kirby's Adventure
   -  kirby_hud patch is for Revised only!  (clear Kirby icon)
   -  Thanks to Rushiomatsu for palette / icon design



_______________________________________________



Commits:


4 - double_speed released


3 - black_fade released


2 - fade_palette released


1 - hud_color released



_______________________________________________



Visit:

*  https://github.com/minucce-yard/Kirbys_Dream_Land_GB



*  Kirby's Dream Land DX
   http://www.romhacking.net/hacks/5213/


   Kirby's Dream Land DX Revised
   http://www.romhacking.net/hacks/5635/

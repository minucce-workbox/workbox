/*
	Code should be used only for educational, documentation and modding purposes.
*/

#include <stdio.h>
#include <memory.h>


#define MEM16(x) *((unsigned short *)(x))


FILE *in, *out;
unsigned int in_size, out_size;
unsigned char in_buffer[0x100000], out_buffer[0x100000];



void encode()
{
	int in_ptr = 0;

	int raw_size = 0, raw_ptr = 0;


	while( in_ptr < in_size ) {
		int best_size = 0;


		// debugging
		if( in_ptr >= 0xa50 )
			in_ptr += 0;


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		int rle1_size = 0;
		const int rle1_min_size = 2+1, rle1_max_size = 0x3ff;


		if(1) {
			int count = 1;


			// find longest rle match  (8-bit)
			for( int lcv = in_ptr+1; lcv < in_size; lcv++ ) {
				if( in_buffer[in_ptr] != in_buffer[lcv] ) break;

				if( (++count) == rle1_max_size ) break;
			}


			// best record
			if( count > rle1_size && count >= rle1_min_size ) {
				rle1_size = count;
			}
		}


		if( rle1_size - rle1_min_size > best_size) {
			best_size = rle1_size * 1 - rle1_min_size;
		}

		else {
			rle1_size = 0;
		}


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		int rle2_size = 0;
		const int rle2_min_size = 2+2, rle2_max_size = 0x3ff;


		if(1) {
			int count = 1;


			// find longest rle match  (16-bit)
			for( int lcv = in_ptr+2; lcv+1 < in_size; lcv += 2 ) {
				if( in_buffer[in_ptr+0] != in_buffer[lcv+0] ) break;
				if( in_buffer[in_ptr+1] != in_buffer[lcv+1] ) break;

				if( (++count) == rle2_max_size ) break;
			}


			// best record
			if( count > rle2_size && count >= rle2_min_size ) {
				rle2_size = count;
			}
		}


		if( rle2_size * 2 - rle2_min_size > best_size) {
			best_size = rle2_size * 2 - rle2_min_size;


			rle1_size = 0;
		}

		else {
			rle2_size = 0;
		}


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		int rle4_size = 0;
		const int rle4_min_size = 2+4, rle4_max_size = 0x3ff;


		if(1) {
			int count = 1;


			// find longest rle match  (32-bit)
			for( int lcv = in_ptr+4; lcv+3 < in_size; lcv += 4 ) {
				if( in_buffer[in_ptr+0] != in_buffer[lcv+0] ) break;
				if( in_buffer[in_ptr+1] != in_buffer[lcv+1] ) break;
				if( in_buffer[in_ptr+2] != in_buffer[lcv+2] ) break;
				if( in_buffer[in_ptr+3] != in_buffer[lcv+3] ) break;

				if( (++count) == rle4_max_size ) break;
			}


			// best record
			if( count > rle4_size && count >= rle4_min_size ) {
				rle4_size = count;
			}
		}


		if( rle4_size * 4 - rle4_min_size > best_size) {
			best_size = rle4_size * 4 - rle4_min_size;


			rle1_size = 0;
			rle2_size = 0;
		}

		else {
			rle4_size = 0;
		}


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		int lz_size = 0, lz_ptr = 0, lz_method = 0;
		const int lz_min_size = 2+2, lz_max_size = 0x3ff;


		// find longest lz string (history)
		for( int lcv = 0; lcv < in_ptr; lcv++ ) {
			int count = 0;


			for( int lcv2 = in_ptr; lcv2 < in_size; lcv2++ ) {
				if( in_buffer[lcv+count] != in_buffer[lcv2] ) break;

				if( (++count) == lz_max_size ) break;
			}


			// best record
			if( count > lz_size && count >= lz_min_size ) {
				lz_size = count;
				lz_ptr = lcv;
			}
		}


		if( lz_size - lz_min_size > best_size) {
			best_size = lz_size * 1 - lz_min_size;


			rle1_size = 0;
			rle2_size = 0;
			rle4_size = 0;
		}

		else {
			lz_size = 0;
		}


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		// peek ahead - better match  (usually works)
		if( lz_size > 0 ) {
			for( int lcv = 0; lcv < in_ptr+1; lcv++ ) {
				int count = 0;


				for( int lcv2 = in_ptr+1; lcv2 < in_size; lcv2++ ) {
					if( in_buffer[lcv+count] != in_buffer[lcv2] ) break;

					if( (++count) == lz_max_size ) break;
				}


				// future best record
				if( raw_size > 0 && count > lz_size && count >= lz_min_size+(1+0) ) {
					rle1_size = 0;
					rle2_size = 0;
					rle4_size = 0;

					lz_size = 0;
					break;
				}


				else if( raw_size == 0 && count > lz_size && count >= lz_min_size+(1+1) ) {
					rle1_size = 0;
					rle2_size = 0;
					rle4_size = 0;

					lz_size = 0;
					break;
				}
			}
		}


		// -------------------------------------------------------------
		// -------------------------------------------------------------


		// debugging
		if( in_ptr >= 0xa50 )
			in_ptr += 0;


		if( rle1_size > 0 ) {
			out_buffer[ out_size++ ] = 0x80 | ( 0 << 2 ) | ( rle1_size >> 8 );
			out_buffer[ out_size++ ] = rle1_size & 0xff;

			out_buffer[ out_size++ ] = in_buffer[ in_ptr ];

			in_ptr += rle1_size * 1;
		}


		else if( rle2_size > 0 ) {
			out_buffer[ out_size++ ] = 0x80 | ( 1 << 2 ) | ( rle2_size >> 8 );
			out_buffer[ out_size++ ] = rle2_size & 0xff;

			out_buffer[ out_size++ ] = in_buffer[ in_ptr+0 ];
			out_buffer[ out_size++ ] = in_buffer[ in_ptr+1 ];

			in_ptr += rle2_size * 2;
		}


		else if( rle4_size > 0 ) {
			out_buffer[ out_size++ ] = 0x80 | ( 2 << 2 ) | ( rle4_size >> 8 );
			out_buffer[ out_size++ ] = rle4_size & 0xff;

			out_buffer[ out_size++ ] = in_buffer[ in_ptr+0 ];
			out_buffer[ out_size++ ] = in_buffer[ in_ptr+1 ];
			out_buffer[ out_size++ ] = in_buffer[ in_ptr+2 ];
			out_buffer[ out_size++ ] = in_buffer[ in_ptr+3 ];

			in_ptr += rle4_size * 4;
		}


		else if( lz_size > 0 ) {
			out_buffer[ out_size++ ] = 0xfc | ( lz_size >> 8 );
			out_buffer[ out_size++ ] = ( lz_size & 0xff );

			out_buffer[ out_size++ ] = lz_ptr & 0xff;
			out_buffer[ out_size++ ] = ( lz_ptr >> 8 ) & 0xff;

			in_ptr += lz_size;
		}


		else {
			// save header
			if( ++raw_size == 1 ) {
				raw_ptr = out_size++;
			}


			out_buffer[ out_size++ ] = in_buffer[ in_ptr++ ];


			if( raw_size == 0x7f ) {
				out_buffer[ raw_ptr ] = raw_size;

				raw_size = 0;
				raw_ptr = out_size;
			}
		}


		if( (rle1_size || rle2_size || rle4_size || lz_size) && raw_size > 0 ) {
			out_buffer[ raw_ptr ] = raw_size;

			raw_ptr = out_size;
			raw_size = 0;
		}
	}


	// flush raw buffer
	if( raw_size > 0 ) {
		out_buffer[ raw_ptr ] = raw_size;
	}


	// stop code
	out_buffer[ out_size++ ] = 0x00;
}



char in_name[4096];
char out_name[4096];

int main( int argc, char** argv )
{
	if( argc >= 3 ) {
		in = fopen( argv[1], "rb" );
		out = fopen( argv[2], "wb" );
	}

	else if( argc == 2 ) {
		sprintf( in_name, "%s.bin", argv[1] );
		in = fopen( in_name, "rb" );

		if( !in ) {
			sprintf( in_name, "%s", argv[1] );
			in = fopen( in_name, "rb" );
		}


		sprintf( out_name, "%s.pack", argv[1] );
		out = fopen( out_name, "wb" );
	}


	fseek( in, 0, SEEK_END );
	in_size = ftell(in);
	fseek( in, 0, SEEK_SET );

	fread( &in_buffer, 1, in_size, in );


	encode();


	printf( "%x ==> %x  [%s]\n", in_size, out_size, in_name );
	fwrite( &out_buffer, 1, out_size, out );


	fclose( in );
	fclose( out );
	return 0;
}
